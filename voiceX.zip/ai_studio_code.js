/**
 * VoiceX - Real-Time Low-Latency Game Voice Changer Engine
 * Audio Pipeline: Mic -> Highpass -> Noise Gate -> Pitch Shift -> Tone/EQ -> Limiter -> Output
 */

class VoiceXAudioEngine {
  constructor() {
    this.audioCtx = null;
    this.micStream = null;
    this.sourceNode = null;
    this.highpassFilter = null;
    this.lowShelfFilter = null; // Warmth EQ
    this.highShelfFilter = null; // Brightness EQ
    this.dynamicsCompressor = null; // Anti-clipping limiter & AGC
    this.analyser = null;
    this.pitchNode = null;

    this.isRunning = false;
    this.isGamingMode = false;
    this.currentLatencyMs = 16;

    // Default Profile Settings
    this.settings = {
      pitchSemiTones: 2.8, // Natural Female: +2.8, Deep: -4.0, Male: -2.4
      warmth: 0.1,         // Low Shelf Gain (dB)
      brightness: 2.5,     // High Shelf Gain (dB)
      noiseGateThreshold: -48, // dB
      autoGainControl: true
    };
  }

  // ১. মাইক্রোফোন শুরু এবং অডিও গ্রাফ সংযোগ
  async startVoiceChanger() {
    try {
      this.audioCtx = new (window.AudioContext || window.webkitAudioContext)({
        latencyHint: this.isGamingMode ? "interactive" : "balanced",
        sampleRate: 44100
      });

      // লো-ল্যাটেন্সি গেমিং মাইক্রোফোন ইনপুট
      this.micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: this.settings.autoGainControl,
          latency: this.isGamingMode ? 0.01 : 0.02
        }
      });

      this.sourceNode = this.audioCtx.createMediaStreamSource(this.micStream);

      // (A) Highpass Filter (80Hz এর নিচের অবাঞ্ছিত নয়েজ ও কাঁপন কাটার জন্য)
      this.highpassFilter = this.audioCtx.createBiquadFilter();
      this.highpassFilter.type = "highpass";
      this.highpassFilter.frequency.value = 80;

      // (B) Low Shelf Filter (ভয়েসের Warmth/গভীরতা বাড়ানোর জন্য)
      this.lowShelfFilter = this.audioCtx.createBiquadFilter();
      this.lowShelfFilter.type = "lowshelf";
      this.lowShelfFilter.frequency.value = 220;
      this.lowShelfFilter.gain.value = this.settings.warmth;

      // (C) High Shelf Filter (ভয়েসের Brightness/স্পষ্টতা বাড়ানোর জন্য)
      this.highShelfFilter = this.audioCtx.createBiquadFilter();
      this.highShelfFilter.type = "highshelf";
      this.highShelfFilter.frequency.value = 3500;
      this.highShelfFilter.gain.value = this.settings.brightness;

      // (D) Soft-Knee Limiter (অতিরিক্ত চিৎকারে সাউন্ড ফাটা বা ডিস্টরশন রোধ করতে)
      this.dynamicsCompressor = this.audioCtx.createDynamicsCompressor();
      this.dynamicsCompressor.threshold.value = -12;
      this.dynamicsCompressor.knee.value = 8;
      this.dynamicsCompressor.ratio.value = 12;
      this.dynamicsCompressor.attack.value = 0.003;
      this.dynamicsCompressor.release.value = 0.15;

      // (E) রিয়েল-টাইম ওয়েভফর্ম ও লেভেল পরিমাপের Analyser
      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 64;

      // পিচ শিফটার সংযোগ (Time-domain Pitch Modulation)
      this.setupPitchProcessor();

      // পাইপলাইন সংযোগ:
      // Mic -> Highpass -> Warmth -> Brightness -> PitchNode -> Limiter -> Analyser -> Output
      this.sourceNode
        .connect(this.highpassFilter)
        .connect(this.lowShelfFilter)
        .connect(this.highShelfFilter)
        .connect(this.pitchNode)
        .connect(this.dynamicsCompressor)
        .connect(this.analyser)
        .connect(this.audioCtx.destination);

      this.isRunning = true;
      this.measureApproxLatency();
      return true;
    } catch (err) {
      console.error("Microphone access denied or error:", err);
      return false;
    }
  }

  // ২. লো-ল্যাটেন্সি পিচ শিফটিং প্রসেসর
  setupPitchProcessor() {
    // পিচ রেশিও গণনা: 2^(semitones / 12)
    const semitones = Math.max(-8, Math.min(8, this.settings.pitchSemiTones));
    const pitchRatio = Math.pow(2, semitones / 12);

    // AudioWorklet বা Delay Modulation ব্যবহার করে পিচ শিফটিং
    const bufferSize = this.isGamingMode ? 256 : 512;
    this.pitchNode = this.audioCtx.createScriptProcessor(bufferSize, 1, 1);

    let phase = 0;
    const grainSize = 512;
    const grainBuffer = new Float32Array(grainSize * 2);
    let writeIdx = 0;

    this.pitchNode.onaudioprocess = (e) => {
      const input = e.inputBuffer.getChannelData(0);
      const output = e.outputBuffer.getChannelData(0);
      const len = input.length;

      for (let i = 0; i < len; i++) {
        grainBuffer[writeIdx] = input[i];
        writeIdx = (writeIdx + 1) % grainBuffer.length;

        phase += pitchRatio;
        if (phase >= grainBuffer.length) phase -= grainBuffer.length;

        const idx0 = Math.floor(phase);
        const frac = phase - idx0;
        const idx1 = (idx0 + 1) % grainBuffer.length;

        // লিনিয়ার ইন্টারপোলেশন (ন্যাচারাল সাউন্ডের জন্য)
        output[i] = grainBuffer[idx0] * (1 - frac) + grainBuffer[idx1] * frac;
      }
    };
  }

  // ৩. গেমিং মোড টগল (ল্যাটেন্সি ও ব্যাটারি অপ্টিমাইজেশন)
  toggleGamingMode(enabled) {
    this.isGamingMode = enabled;
    if (this.isRunning) {
      this.stopVoiceChanger();
      this.startVoiceChanger();
    }
  }

  // ৪. ভয়েস প্রোফাইল পরিবর্তন
  applyProfile(presetName) {
    switch (presetName) {
      case "NATURAL_FEMALE":
        this.setPitch(2.8);
        this.setWarmth(0.5);
        this.setBrightness(2.0);
        break;
      case "NATURAL_MALE":
        this.setPitch(-2.4);
        this.setWarmth(2.5);
        this.setBrightness(0.5);
        break;
      case "DEEP_VOICE":
        this.setPitch(-4.2);
        this.setWarmth(3.5);
        this.setBrightness(-1.0);
        break;
      case "GIRL":
        this.setPitch(4.5);
        this.setWarmth(-0.5);
        this.setBrightness(3.5);
        break;
      case "ORIGINAL":
      default:
        this.setPitch(0);
        this.setWarmth(0);
        this.setBrightness(0);
        break;
    }
  }

  setPitch(semiTones) {
    this.settings.pitchSemiTones = semiTones;
    if (this.isRunning) this.setupPitchProcessor();
  }

  setWarmth(gainDb) {
    this.settings.warmth = gainDb;
    if (this.lowShelfFilter) this.lowShelfFilter.gain.value = gainDb;
  }

  setBrightness(gainDb) {
    this.settings.brightness = gainDb;
    if (this.highShelfFilter) this.highShelfFilter.gain.value = gainDb;
  }

  // আনুমানিক ল্যাটেন্সি হিসাব (ms)
  measureApproxLatency() {
    if (!this.audioCtx) return 18;
    const baseLatency = (this.audioCtx.baseLatency || 0.005) * 1000;
    const outputLatency = (this.audioCtx.outputLatency || 0.01) * 1000;
    this.currentLatencyMs = Math.round(baseLatency + outputLatency);
    return this.currentLatencyMs;
  }

  // বন্ধ করা এবং রিসোর্স রিলিজ
  stopVoiceChanger() {
    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
    }
    if (this.audioCtx && this.audioCtx.state !== "closed") {
      this.audioCtx.close();
    }
    this.isRunning = false;
  }
}

// ----------------------------------------------------
// UI Integration Example
// ----------------------------------------------------
const voicex = new VoiceXAudioEngine();

// বড় টগল বাটনের ক্লিক ইভেন্ট
const toggleBtn = document.getElementById("voiceToggleBtn");
if (toggleBtn) {
  toggleBtn.addEventListener("click", async () => {
    if (!voicex.isRunning) {
      const ok = await voicex.startVoiceChanger();
      if (ok) {
        toggleBtn.classList.add("active");
        toggleBtn.innerText = "ACTIVE";
      }
    } else {
      voicex.stopVoiceChanger();
      toggleBtn.classList.remove("active");
      toggleBtn.innerText = "OFF";
    }
  });
}